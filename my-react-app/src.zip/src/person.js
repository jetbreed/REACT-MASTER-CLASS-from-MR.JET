

// export const name1 = "Charles";
// export const name2 = "Chris";


const name1 = "Charles";
const name2 = "Chris";
export {name1, name2}