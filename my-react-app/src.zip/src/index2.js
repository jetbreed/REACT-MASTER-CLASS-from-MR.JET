
const myArray = ['apple', 'banana', 'orange'];

const myFruits = myArray.map((item) => <p>{item}</p>);

export default myFruits;