import React from 'react';
import ReactDOM from 'react-dom/client';

// This is JSX (JavaScript Extentible Language)
const myNames = (
  <table>
    <tr>
      <th>Name</th>
    </tr>
    <tr>
      <td>John</td>
    </tr>
    <tr>
      <td>Elsa</td>
    </tr>
  </table>
);

export default myNames;