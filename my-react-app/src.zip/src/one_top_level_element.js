import React from 'react';
import ReactDOM from 'react-dom/client';

const myElement = (
  <>
    <h1>I am a Header.</h1>
    <h1>I am a Header too.</h1>
  </>
);

export default myElement;