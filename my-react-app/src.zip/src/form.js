import React from "react";
import ReactDOM from "react";


const form = (
    <>
    <h2>WEB FORM</h2>
     Name: <input value={5+5} type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     Name: <input type='text'/><br/><br/>
     <input type='submit' value='SUBMIT'/>
     <br/><br/>
    </>
);
export default form;