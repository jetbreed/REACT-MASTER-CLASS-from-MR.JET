
import React from 'react';
import ReactDOM from 'react-dom/client';
import myNames from './html1';
import myFruits from './index2';
import myElement from './one_top_level_element';
import form from './form';
import jsx_tenary from './jsx_tenary';

// >>> Executes
const root = ReactDOM
.createRoot(document.getElementById('root'));

// root.render(myFruits);
// root.render(myNames);
// root.render(form);
root.render(jsx_tenary);


























